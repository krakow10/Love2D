--By xXxMoNkEyMaNxXx
local version=0.1

local speed=100
local thickness=25
local damping=25
local rolloff=15
local resonance=0.1

local vec=require'vec'
local ui=loader.open'ui.lua'

local tick=love.timer.getMicroTime
local rect=love.graphics.rectangle
local setEffect=love.graphics.setPixelEffect

local w=ui.connect(ctrl.newWindow())
local wrapper=ui.wrapper(w)
wrapper.TitleBar.Text="Splash V"..string.format("%.1f",version)

local effect=love.graphics.newPixelEffect(love.filesystem.read'Splash/shader.glsl')
local send=effect.send

local C0={1,1,1,1}
local C1={0,0,1,1}

send(effect,"t",tick())
send(effect,"View",w.View)
send(effect,"h",love.graphics.getHeight())
send(effect,"C0",C0)
send(effect,"C1",C1)
send(effect,"speed",speed)
send(effect,"thickness",thickness)
send(effect,"damping",damping)
send(effect,"rolloff",rolloff)
send(effect,"resonance",resonance)

function w:draw()
	setEffect(effect)
	rect("fill",self.View[1][1],self.View[1][2],self.View[2][1],self.View[2][2])
	setEffect()
end

function w:update(t)
	send(effect,"t",tick())
	send(effect,"View",w.View)
end

local nmod=16
local n=0
function w:mousepressed(b)
	send(effect,"sEvt["..n.."]",tick())
	send(effect,"sPos["..n.."]",w.m)
	n=(n+1)%nmod
end

w.Control._BringToFront={"MDl","MDr"}
