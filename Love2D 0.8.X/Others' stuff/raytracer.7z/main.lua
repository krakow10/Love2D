-----------------------------------------------------------------------------------
--------Raycasting + textures code written by Ben White (scutheotaku), 2012 -------
--------Based on code by Lode Vandevenne (http://lodev.org/cgtutor/raycasting.html)
-----------------------------------------------------------------------------------
-------
------
-----
----
---
--

--setup map
map={
  {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,2,2,2,2,2,0,0,0,0,3,0,3,0,3,0,0,0,1},
  {1,0,0,0,0,0,2,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,2,0,0,0,2,0,0,0,0,3,0,0,0,3,0,0,0,1},
  {1,0,0,0,0,0,2,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,2,2,0,2,2,0,0,0,0,3,0,3,0,3,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,4,4,4,4,4,4,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,4,0,4,0,0,0,0,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,4,0,0,0,0,5,0,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,4,0,4,0,0,0,0,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,4,0,4,4,4,4,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,4,4,4,4,4,4,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
};

function love.load()
	--x start position
	posX = 22
	--y start position
	posY = 12
	
	playerHeight = 0;
	
	--initial direction vector
	dirX = -1
	dirY = 0
	--camera plane
	planeX = 0
	planeY = 0.66
	
	--set screen/window width and height
	w = 640
	h = 480
	love.graphics.setMode(w, h, false, true, 0)
	
	--change default image filter to reduce bluriness when scaling images
	love.graphics.setDefaultImageFilter("nearest","nearest")
	
	--screen drawing arrays
	drawScreenLineStart = {}
	drawScreenLineOriginalStart = {}
	drawScreenLineX = {}
	drawScreenTexture = {}
	drawScreenQuad = {}
	drawScreenLineEnd = {}
	drawScreenLineOriginalEnd = {}
	drawScreenLineColor = {}
	
	--set texture width and height - FYI if you want textures of a variety of different sizes, you should be able to uses tables to achieve this
	texWidth = 64
	texHeight = 64
	
	--setup texture table
	texture = {}
	--setup example textures, courtesy of id Software's Wolfenstein 3D
	texture[0] = love.graphics.newImage("assets/gfx/greystone.png")
	texture[1] = love.graphics.newImage("assets/gfx/mossy.png")
	texture[2] = love.graphics.newImage("assets/gfx/redbrick.png")
	texture[3] = love.graphics.newImage("assets/gfx/wood.png")
	texture[4] = love.graphics.newImage("assets/gfx/eagle.png")
end

function love.update(dt)
	for x = 0, w, 1 do
		--x coordinate in camera space
		local cameraX = 2 * x / w - 1
		
		local rayPosX = posX
		local rayPosY = posY
		local rayDirX = dirX + planeX * cameraX
		local rayDirY = dirY + planeY * cameraX
		
		--which box of the map we're in
		local mapX = math.floor(rayPosX)
		local mapY = math.floor(rayPosY)
		
		--length of the ray from curent position to next x or y-side
		local sideDistX
		local sideDistY
		
		--length of ray from one x or y-side to next x or y-side
		local deltaDistX = math.sqrt(1 + (rayDirY * rayDirY) / (rayDirX * rayDirX))
		local deltaDistY = math.sqrt(1 + (rayDirX * rayDirX) / (rayDirY * rayDirY))
		local perpWallDist
		
		--what direction to step in x or y-direction (either +1 or -1)
		local stepX
		local stepY
		
		--was there a wall hit?
		local hit = 0
		--was a NS or a EW wall hit?
		local side = 0
		
		--calculate step and initial sideDist
		if (rayDirX < 0) then
			stepX = -1
			sideDistX = (rayPosX - mapX) * deltaDistX
		else
			stepX = 1
			sideDistX = (mapX + 1 - rayPosX) * deltaDistX
		end
		if (rayDirY < 0) then
			stepY = -1
			sideDistY = (rayPosY - mapY) * deltaDistY
		else
			stepY = 1
			sideDistY = (mapY + 1 - rayPosY) * deltaDistY
		end
		
		--perform DDA
		while hit == 0 do
			if (sideDistX < sideDistY) then
				sideDistX = sideDistX + deltaDistX
				mapX = mapX + stepX
				side = 0
			else
				sideDistY = sideDistY + deltaDistY
				mapY = mapY + stepY
				side = 1
			end
			if (map[mapX][mapY] > 0) then hit = 1 end
		end
		 
		--Calculate distance projected on camera direction (obligque distance will give fisheye effect)
		if (side == 0) then
			perpWallDist = math.abs((mapX - rayPosX + (1 - stepX) / 2) / rayDirX)
		else
			perpWallDist = math.abs((mapY - rayPosY + (1 - stepY) / 2) / rayDirY)
		end
		
		--Calculate height of line to draw on screen
		lineHeight = math.abs(math.floor(h / perpWallDist))
		
		drawStart = -lineHeight / 2 + h / 2
		drawScreenLineOriginalStart[x] = drawStart
		if (drawStart < 0) then drawStart = 0 end
		drawEnd = lineHeight / 2 + h / 2
		drawScreenLineOriginalEnd[x] = drawEnd
		if (drawEnd >= h) then drawEnd = h - 1 end
		
		--y side shading
		if (side == 1) then
			drawScreenLineColor[x] = {127,127,127,255}
		else
			drawScreenLineColor[x] = {255,255,255,255}
		end
		
		--texturing calculations
		local texNum = map[mapX][mapY] - 1
		
		--calculate value of wallX
		local wallX
		if (side == 1) then wallX = rayPosX + ((mapY - rayPosY + (1 - stepY) / 2) / rayDirY) * rayDirX
		else wallX = rayPosY + ((mapX - rayPosX + (1 - stepX) / 2) / rayDirX) * rayDirY end
		wallX = wallX - math.floor(wallX)
		
		--x coordinate on the texture
		local texX = math.floor(wallX * texWidth)
		if (side == 0 and rayDirX > 0) then texX = texWidth - texX - 1 end
		if (side == 1 and rayDirY < 0) then texX = texWidth - texX - 1 end
		
		--set draw array variables
		drawScreenLineStart[x] = drawStart
		drawScreenLineEnd[x] = drawEnd	
		drawScreenLineX[x] = texX
		drawScreenTexture[x] = texNum
	end
	
	--set move & rotation speeds
	moveSpeed = 4 * dt
	strafeSpeed = 4 * dt
	rotSpeed = 2 * dt
	
	--move forward if no wall is in front of you
	if love.keyboard.isDown('up') then
		if (map[math.floor(posX + dirX * moveSpeed)][math.floor(posY)] == 0) then
			posX = posX + dirX * moveSpeed
		end
		if (map[math.floor(posX)][math.floor(posY + dirY * moveSpeed)] == 0) then
			posY = posY + dirY * moveSpeed
		end
	end
	--move backwards if no wall is behind you
	if love.keyboard.isDown('down') then
		if (map[math.floor(posX - dirX * moveSpeed)][math.floor(posY)] == 0) then
			posX = posX - dirX * moveSpeed
		end
		if (map[math.floor(posX)][math.floor(posY - dirY * moveSpeed)] == 0) then
			posY = posY - dirY * moveSpeed
		end
	end
	--strafe right if no wall is to the right of you
	if love.keyboard.isDown('x') then
		if (map[math.floor(posX + planeX + 0.1 * moveSpeed)][math.floor(posY)] == 0) then
			posX = posX + planeX * strafeSpeed
		end
		if (map[math.floor(posX)][math.floor(posY + planeY + 0.1 * moveSpeed)] == 0) then
			posY = posY + planeY * strafeSpeed
		end
	end
	--strafe left if no wall is to the left of you
	if love.keyboard.isDown('z') then
		if (map[math.floor(posX - planeX - 0.01 * moveSpeed)][math.floor(posY)] == 0) then
			posX = posX - planeX * strafeSpeed
		end
		if (map[math.floor(posX)][math.floor(posY - planeY - 0.01 * moveSpeed)] == 0) then
			posY = posY - planeY * strafeSpeed
		end
	end
	--rotate to the right
	if love.keyboard.isDown('right') then
		oldDirX = dirX
		dirX = dirX * math.cos(-rotSpeed) - dirY * math.sin(-rotSpeed)
		dirY = oldDirX * math.sin(-rotSpeed) + dirY * math.cos(-rotSpeed)
		oldPlaneX = planeX
		planeX = planeX * math.cos(-rotSpeed) - planeY * math.sin(-rotSpeed)
		planeY = oldPlaneX * math.sin(-rotSpeed) + planeY * math.cos(-rotSpeed)
	end
	--rotate to the left
	if love.keyboard.isDown('left') then
		oldDirX = dirX
		dirX = dirX * math.cos(rotSpeed) - dirY * math.sin(rotSpeed)
		dirY = oldDirX * math.sin(rotSpeed) + dirY * math.cos(rotSpeed)
		oldPlaneX = planeX
		planeX = planeX * math.cos(rotSpeed) - planeY * math.sin(rotSpeed)
		planeY = oldPlaneX * math.sin(rotSpeed) + planeY * math.cos(rotSpeed)
	end
	if love.keyboard.isDown('u') then
		playerHeight = playerHeight + rotSpeed*500
	end
	if love.keyboard.isDown('i') then
		playerHeight = playerHeight - rotSpeed*500
	end
end

function love.draw()
	for x = 0, w, 1 do
		--drawing...there's probably (no, definitely) a better way to do this!
		love.graphics.setColor(drawScreenLineColor[x])
		drawScreenQuad[x] = love.graphics.newQuad(drawScreenLineX[x], 0, 1, texHeight, texWidth, texHeight)
		local texYScale = (drawScreenLineOriginalEnd[x] - drawScreenLineOriginalStart[x]) / texHeight
		local texXScale = 1
		love.graphics.drawq(texture[drawScreenTexture[x]], drawScreenQuad[x], x, drawScreenLineOriginalStart[x] + playerHeight, 0, texXScale, texYScale)
	end
	
	--draw FPS
	love.graphics.setColor(255, 255, 255)
	love.graphics.print("Current FPS: "..tostring(love.timer.getFPS( )), 5, 5)
	
	--draw instructions
	love.graphics.print("Arrow keys to move and turn, 'z' and 'x' to strafe, 'r' to change window/screen size", 5, h - 20)
	
	--change screen resolution
	if love.keyboard.isDown('r') then
		if (w < 1280) then
			if (w < 1024) then
				if (w < 800) then
					w = 800
					h = 600
				else
					w = 1024
					h = 768
				end
			else
				w = 1280
				h = 1024
			end
		else
			w = 640
			h = 480
		end
	love.graphics.setMode(w, h)
	end
end







