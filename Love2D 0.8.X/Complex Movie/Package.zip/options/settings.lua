--Settings

--Image to render (Folder callled "Images" in Appdata\Roaming\LOVE)
image="nature.jpg"

--Resolution, duration, and framerate of the video
resolution={1920,1080}
duration=10
fps=30

--If it "fails" while rendering, set this to the frame it got to.
start=0

--View of the complex plane (2 would be -2-2i to 2+2i)
view=5
